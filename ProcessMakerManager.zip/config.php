<?php

$db_host = 'localhost';
$db_user = 'processmaker';
$db_pass = 'password';
$db_name = 'pmmanager';



?>
